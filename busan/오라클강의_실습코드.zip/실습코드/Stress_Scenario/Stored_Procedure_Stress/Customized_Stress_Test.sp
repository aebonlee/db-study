create or replace type integer_return_array is varray(25) of integer
/

CREATE OR REPLACE PACKAGE SOE_10G.swingbench AS


  function storedprocedure1(min_sleep integer, max_sleep integer) return integer_return_array;
  function storedprocedure2(min_sleep integer, max_sleep integer) return integer_return_array;
  function storedprocedure3(min_sleep integer, max_sleep integer) return integer_return_array;
  function storedprocedure4(min_sleep integer, max_sleep integer) return integer_return_array;
  function storedprocedure5(min_sleep integer, max_sleep integer) return integer_return_array;
  function storedprocedure6(min_sleep integer, max_sleep integer) return integer_return_array;
END;
/

CREATE OR REPLACE PACKAGE BODY SOE_10G.swingbench AS
  SELECT_STATEMENTS   integer := 1;
  INSERT_STATEMENTS   integer := 2;
  UPDATE_STATEMENTS   integer := 3;
  DELETE_STATEMENTS   integer := 4;
  COMMIT_STATEMENTS   integer := 5;
  ROLLBACK_STATEMENTS integer := 6;
  SLEEP_TIME          integer := 7;
  info_array integer_return_array := integer_return_array();
  function from_mills_to_tens(value integer) return float is
    real_value float := 0;
    begin
      real_value := value/1000;
      return real_value;
      exception
        when zero_divide then
          real_value := 0;
          return real_value;
  END FROM_MILLS_TO_TENS;
  function from_mills_to_secs(value integer) return float is
    real_value float := 0;
    begin
      real_value := value/1000;
      return real_value;
      exception
        when zero_divide then
          real_value := 0;
          return real_value;
  end from_mills_to_secs;
  procedure sleep(min_sleep integer, max_sleep integer) is
    sleeptime number := 0;
    begin
      if (max_sleep = min_sleep) then
        sleeptime := from_mills_to_secs(max_sleep);
        dbms_lock.sleep(sleeptime);
      elsif (((max_sleep - min_sleep) > 0) AND (min_sleep < max_sleep)) then
        sleeptime := dbms_random.value(from_mills_to_secs(min_sleep), from_mills_to_secs(max_sleep));
        dbms_lock.sleep(sleeptime);
     end if;
     info_array(SLEEP_TIME) := (sleeptime * 1000) + info_array(SLEEP_TIME);
  end sleep;
  procedure init_dml_array is
    begin
      info_array := integer_return_array();
      for i in 1..7 loop
        info_array.extend;
        info_array(i) := 0;
      end loop;
  end init_dml_array;
  procedure increment_selects(num_selects integer) is
    begin
      info_array(SELECT_STATEMENTS) := info_array(SELECT_STATEMENTS) + num_selects;
  end increment_selects;
  procedure increment_inserts(num_inserts integer) is
    begin
      info_array(INSERT_STATEMENTS) := info_array(INSERT_STATEMENTS) + num_inserts;
  end increment_inserts;
  procedure increment_updates(num_updates integer) is
    begin
      info_array(UPDATE_STATEMENTS) := info_array(UPDATE_STATEMENTS) + num_updates;
  end increment_updates;
  procedure increment_deletes(num_deletes integer) is
    begin
      info_array(DELETE_STATEMENTS) := info_array(DELETE_STATEMENTS) + num_deletes;
  end increment_deletes;
  procedure increment_commits(num_commits integer) is
    begin
      info_array(COMMIT_STATEMENTS) := info_array(COMMIT_STATEMENTS) + num_commits;
  end increment_commits;
  procedure increment_rollbacks(num_rollbacks integer) is
    begin
      info_array(ROLLBACK_STATEMENTS) := info_array(ROLLBACK_STATEMENTS) + num_rollbacks;
  end increment_rollbacks;
  
  function SalesRepsQuery(salesRep orders.sales_rep_id%type, min_sleep integer,    
                           max_sleep integer) return integer_return_array is    
    cursor c1 is SELECT tt.ORDER_TOTAL,
          tt.SALES_REP_ID,
          tt.ORDER_DATE,
          customers.CUST_FIRST_NAME,
          customers.CUST_LAST_NAME
        FROM
          (SELECT orders.ORDER_TOTAL,
            orders.SALES_REP_ID,
            orders.ORDER_DATE,
            orders.customer_id,
            rank() Over (Order By orders.ORDER_TOTAL DESC) sal_rank
          FROM orders
          WHERE orders.SALES_REP_ID = salesRep
          ) tt,
          customers
        WHERE tt.sal_rank        <= 100
        AND customers.customer_id = tt.customer_id;
        order_total orders.order_total%type;
        sales_rep_id orders.sales_rep_id%type;
        order_date orders.order_date%type;
        cust_first_name customers.cust_first_name%type;
        cust_last_name customers.cust_last_name%type;        
    begin    
      dbms_application_info.set_module('Sales Rep Query',null);      
      open c1;
      loop
        fetch c1 into order_total,sales_rep_id,order_date,cust_first_name,cust_last_name;
        exit when c1%notfound;
      end loop;
      increment_selects(1);    
      sleep(min_sleep, max_sleep);    
      dbms_application_info.set_module(null,null);    
      return info_array;    
      exception when others then       
        dbms_application_info.set_module(null,null);    
        return info_array;    
  end SalesRepsQuery;

  function storedprocedure1(min_sleep integer, max_sleep integer) return integer_return_array is
  salesRep INTEGER;
  salesRepTemp INTEGER;
  ord_cnt INTEGER;
  quantity INTEGER;
    begin
      init_dml_array();
      dbms_application_info.set_module('SP1',null);
      salesRepTemp := floor(dbms_random.value(400, 500));
      SELECT /*+ USE_NL(A B) */ A.SALES_REP_ID, COUNT(A.ORDER_TOTAL), SUM(B.QUANTITY) INTO salesRep, ord_cnt, quantity
		FROM ORDERS A, ORDER_ITEMS B WHERE A.ORDER_ID = B.ORDER_ID 
		AND A.SALES_REP_ID = salesRepTemp GROUP BY SALES_REP_ID;
      increment_selects(1);
      sleep(min_sleep, max_sleep);
      return info_array;
  end storedprocedure1;
  
  function storedprocedure2(min_sleep integer, max_sleep integer) return integer_return_array is
  cnt INTEGER;
  prod_id INTEGER;
    begin
      init_dml_array();
      dbms_application_info.set_module('SP2',null);
      cnt := 0;
      prod_id := floor(dbms_random.value(1, 999));
      SELECT /*+ FULL(A) */ count(*) CNT INTO cnt FROM ORDER_ITEMS A WHERE PRODUCT_ID = prod_id AND UNIT_PRICE > 1000;
      increment_selects(1);
      sleep(min_sleep, max_sleep);
      return info_array;
  end storedprocedure2;
  
  function storedprocedure3(min_sleep integer, max_sleep integer) return integer_return_array is
  salesRep INTEGER;  
    begin
      init_dml_array();
      dbms_application_info.set_module('SP3',null);
      salesRep := floor(dbms_random.value(200, 500));
      info_array := SalesRepsQuery(salesRep, min_sleep, max_sleep);
      return info_array;
  end storedprocedure3;
  
  function storedprocedure4(min_sleep integer, max_sleep integer) return integer_return_array is
    begin
      init_dml_array();
      sleep(min_sleep, max_sleep);
      return info_array;
  end storedprocedure4;

  function storedprocedure5(min_sleep integer, max_sleep integer) return integer_return_array is
    begin
      init_dml_array();
      sleep(min_sleep, max_sleep);
      return info_array;
  end storedprocedure5;

  function storedprocedure6(min_sleep integer, max_sleep integer) return integer_return_array is
    begin
      init_dml_array();
      sleep(min_sleep, max_sleep);
      return info_array;
  end storedprocedure6;
END;
/
