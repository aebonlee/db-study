export ORACLE_HOME=/u01/app/oracle/product/18.0.0/dbhome_1
export PATH=${ORACLE_HOME}/bin:${PATH}
echo "Pleas enter database sid you like to delete:"
read -s ORACLE_SID
echo "Please enter sys password"
read -s ORA_PWD
echo "Now starting deletion"
${ORACLE_HOME}/bin/dbca -silent -deleteDatabase -sourceDB ${ORACLE_SID} -sysDBAUserName sys -sysDBAPassword ${ORA_PWD}